package com.example.parkingapp.screen.city.details;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.parkingapp.R;

public class CityDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_details);
    }
}