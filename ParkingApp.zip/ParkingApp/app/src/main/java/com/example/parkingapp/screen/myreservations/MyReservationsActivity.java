package com.example.parkingapp.screen.myreservations;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.parkingapp.R;

public class MyReservationsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_reservations);
    }
}